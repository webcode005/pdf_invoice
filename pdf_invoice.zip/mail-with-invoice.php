<?php 

     $name = "Basant mallick";
     $email = "basant.malick@ictlsquad.com";
     $phone = "9868456854";
          
            // Sender 
            $from = 'support@mindcypress.com'; 
            $fromName = 'Mindcypress'; 
          
          // Email body content 
        $htmlContent = " 
             <p><b>Name:</b> ".$name."</p>
                  <p><b>Email ID:</b> ".$email."</p>
                  <p><b>Mobile Number:</b> ".$phone."</p>          
                  <p><b>Position For:</b> categ</p>
                  <p><b>User Exp:</b> userexp</p>
                "; 
 
            
            $to1 = $email; 
            $from1 = 'cs@mindcypress.biz'; 
            $fromName1 = 'Mindcypress Customer Service'; 
             
            $subject1 = "MindCypress Invoice &amp; Enrollment Details for Training"; 
            
            
            // include'invoice-order.php';
            
            // $htmlContent .="$html1";
        
        
            require"pdf_invoice.php";
    
              $inv_no = "MC00" .$ord_id;
        
              $file="invoice/".$inv_no.'.pdf'; 

       // $file="invoice/MC00234656.pdf"; 
		
		
		//echo file_exists($file); die();
			
	  // Header for sender info 
        $headers1 = "From: $fromName1"." <".$from1.">"; 
         
        // Boundary  
        $semi_rand = md5(time());  
        $mime_boundary = "==Multipart_Boundary_x{$semi_rand}x";  
         
        // Headers for attachment  
        $headers1 .= "\nMIME-Version: 1.0\n" . "Content-Type: multipart/mixed;\n" . " boundary=\"{$mime_boundary}\""; 
         
        // Multipart boundary  
        $message1 = "--{$mime_boundary}\n" . "Content-Type: text/html; charset=\"UTF-8\"\n" . 
        "Content-Transfer-Encoding: 7bit\n\n" . $htmlContent . "\n\n";  
         
        // Preparing attachment 
        if(!empty($file) > 0){ 
            if(is_file($file)){ 
                $message1 .= "--{$mime_boundary}\n"; 
                $fp =    @fopen($file,"rb"); 
                $data =  @fread($fp,filesize($file)); 
         
                @fclose($fp); 
                $data = chunk_split(base64_encode($data)); 
                $message1 .= "Content-Type: application/octet-stream; name=\"".basename($file)."\"\n" .  
                "Content-Description: ".basename($file)."\n" . 
                "Content-Disposition: attachment;\n" . " filename=\"".basename($file)."\"; size=".filesize($file).";\n" .  
                "Content-Transfer-Encoding: base64\n\n" . $data . "\n\n"; 
            } 
        } 
        $message1 .= "--{$mime_boundary}--"; 
        $returnpath = "-f" . $from1; 
 
// Send email 
 
         
		$retval = mail($to1, $subject1, $message1, $headers1, $returnpath); 
          
         
           if( $retval == true ) 
    {
       echo "File Sent Successfully123.";
       die();
       //unlink($name); // delete the file after attachment sent.
    }
    else
    {
       die("Sorry but the email could not be sent.
                    Please go back and try again!");
    }

//}
?>